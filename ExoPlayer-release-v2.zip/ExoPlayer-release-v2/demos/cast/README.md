# Cast demo application #

This folder contains a demo application that showcases ExoPlayer integration
with Google Cast.
